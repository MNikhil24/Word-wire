package com.example.wordwire

class ModelLanguage(var languagecode: String, var languageTitle: String) {
}