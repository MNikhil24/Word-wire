package com.example.wordwire

import android.app.ProgressDialog
import android.content.Context
import android.util.Log
import android.view.Gravity
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.view.animation.Animation
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.google.android.material.button.MaterialButton
import com.google.android.play.core.integrity.e
import com.google.firebase.auth.FirebaseAuth
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter(val context: Context, val messageList: ArrayList<Message>): RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val VIEW_TYPE_SEND = 1
        const val VIEW_TYPE_RECEIVE = 2
        const val TAG = "MAIN_TAG"
    }


    private var sourceLanguageCode = "en"
    private var sourceLanguageTitle = "English"
    private var targetLangeCode = "es"
    private var targetLanguageTitle = "Spanish"

    private var languageArrayList: java.util.ArrayList<ModelLanguage>? = null

    private lateinit var translateOptions: TranslatorOptions

    private lateinit var translator: Translator

    private lateinit var progressDialog: ProgressDialog



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {


        return if (viewType == VIEW_TYPE_SEND) {
            val view = View.inflate(context, R.layout.send, null)
            SendViewHolder(view)

        } else {
            val view = View.inflate(context, R.layout.receive, null)
            ReceiveViewHolder(view)
        }
    }

    override fun getItemCount(): Int {
        return messageList.size
    }

    override fun getItemViewType(position: Int): Int {

        val currentMessage = messageList[position]

        return if (FirebaseAuth.getInstance().currentUser?.uid.equals(currentMessage.senderId)) {
            VIEW_TYPE_SEND

        } else {
            VIEW_TYPE_RECEIVE
        }
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        try {
            val currentMessage = messageList[position]
            if (holder.javaClass == SendViewHolder::class.java){
                val viewHolder = holder as SendViewHolder
                holder.sendMessage.text = currentMessage.message
                //holder.timestampTextView.text = formatTimestamp(currentMessage.timestamp)




            }else{
                val viewHolder = holder as ReceiveViewHolder
                holder.receiveMessage.text = currentMessage.message
                //holder.timestampTextView.text = formatTimestamp(currentMessage.timestamp)
                holder.receiveMessage.setOnClickListener {
                    showTranslatePopup(it, currentMessage.message ?:"")
                }
            }
            holder.itemView.setOnLongClickListener { v ->
                showPopup(v)
                true
            }



        } catch (e: Exception) {
            // Log the error message to Logcat
            Log.e("MessageAdapter", "Error in onBindViewHolder: ${e.message}")
        }
//        fun sendMessage(messageText: String) {
//            val senderId = FirebaseAuth.getInstance().currentUser?.uid
//            val timestamp = System.currentTimeMillis()
//            val newMessage = Message(messageText, senderId, timestamp)
//            messageList.add(newMessage)
//            .notifyDataSetChanged()
//        }

    }
    private fun showTranslatePopup(view: View, message: String) {
        val popupView = View.inflate(context, R.layout.translation_popup, null)

        // Here, we'll populate the original and translated text fields in the popup.
        val sourceLanguageEt: EditText = popupView.findViewById(R.id.originalText)
        val targetLanguageEt: EditText = popupView.findViewById(R.id.translatedText)

        var sourceLangugeChooseBtn: AppCompatButton = popupView.findViewById(R.id.sourceBtn)
        var targetLanguageChooseBtn: AppCompatButton = popupView.findViewById(R.id.destinationLanguageBtn)

        var translateBtn: AppCompatButton = popupView.findViewById(R.id.translateBtn)


        progressDialog = ProgressDialog(context)
        progressDialog.setTitle("please wait")
        progressDialog.setCanceledOnTouchOutside(false)


        loadAvailableLanguages()

        sourceLanguageEt.setText(message)

        sourceLangugeChooseBtn.setOnClickListener {

            sourceLanguageChoose(sourceLangugeChooseBtn)

        }

        targetLanguageChooseBtn.setOnClickListener {

            targetLanguageChose(targetLanguageChooseBtn)
        }

        translateBtn.setOnClickListener {
            valdataData(sourceLanguageEt,targetLanguageEt)

        }

        val popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )


        val slideUp = android.view.animation.AnimationUtils.loadAnimation(context, R.anim.slide_up)
        popupWindow.animationStyle = R.style.PopupAnimation
        popupView.startAnimation(slideUp)
        popupWindow.showAtLocation(view, Gravity.BOTTOM, 0, 0)
        popupWindow.setBackgroundDrawable(ContextCompat.getDrawable(context, android.R.drawable.screen_background_light_transparent))
        val cancelButton: ImageView = popupView.findViewById(R.id.cancelButton)
        cancelButton.setOnClickListener {
            val slideDown = android.view.animation.AnimationUtils.loadAnimation(context, R.anim.slide_down)
            popupView.startAnimation(slideDown)
            slideDown.setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationRepeat(animation: Animation?) {}
                override fun onAnimationEnd(animation: Animation?) {
                    popupWindow.dismiss()
                }
                override fun onAnimationStart(animation: Animation?) {}
            })
        }
    }

    private var sourceLanguageText = ""
    private fun valdataData(sourcLanguageEt:EditText,targetLanguageEt:EditText) {

        sourceLanguageText = sourcLanguageEt.text.toString().trim()
        Log.d(TAG,"validation: sourceLanguage:$sourceLanguageText")

        if(sourceLanguageText.isEmpty()){
            showToast("Enter text to Transalte")
        }
        else{
            startTranslation(targetLanguageEt)
        }
    }

    private fun startTranslation(targetLanguageEt: EditText) {
        progressDialog.setMessage("Processing language model....")
        progressDialog.show()

        translateOptions = TranslatorOptions.Builder().setSourceLanguage(sourceLanguageCode)
            .setTargetLanguage(targetLangeCode).build()
        translator = Translation.getClient(translateOptions)

        val downloadContions = DownloadConditions.Builder().requireWifi().build()

        translator.downloadModelIfNeeded(downloadContions).addOnSuccessListener {
            Log.d(TAG, "startTranslation: model ready, start translation....")

            progressDialog.setMessage("Translating....")
            translator.translate(sourceLanguageText).addOnSuccessListener { translatedText ->
                Log.d(TAG,"startTranslation: Translatin:$translatedText")
                progressDialog.dismiss()
                targetLanguageEt.setText(translatedText)
            }.addOnFailureListener { e ->
                progressDialog.dismiss()
                Log.e(TAG,"startTranslation",e)
                showToast(("Failed to Translate due to ${e.message}"))

            }
        }.addOnFailureListener{e->

            progressDialog.dismiss()
            Log.e(TAG,"startTranslation: ", e)
            showToast("Failied due to ${e.message}")


        }

    }

    private fun showToast(message:String){
        Toast.makeText(context,message,Toast.LENGTH_LONG).show()
    }

    private fun loadAvailableLanguages(){
        languageArrayList = ArrayList()

        val languageCodeList = TranslateLanguage.getAllLanguages()

        for (languageCode in languageCodeList){
            val languageTitle = Locale(languageCode).displayLanguage
            Log.d(TAG,"loadAvailableLanguage: languageCode: $languageCode")
            Log.d(TAG,"loadAvailableLanguage: languageTitle: $languageTitle")

            val modelLanguage = ModelLanguage(languageCode, languageTitle)

            languageArrayList!!.add(modelLanguage)
        }

    }


    fun formatTimestamp(timestamp: Long): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val date = Date(timestamp)
        return sdf.format(date)
    }

    private fun sourceLanguageChoose(sourceLangugeChooseBtn: Button){
        val popupMenu = PopupMenu(context, sourceLangugeChooseBtn)

        for (i in languageArrayList!!.indices){
            popupMenu.menu.add(Menu.NONE, i, i, languageArrayList!![i].languageTitle)
        }
        popupMenu.show()

        popupMenu.setOnMenuItemClickListener { menuItem ->
            val position = menuItem.itemId

            sourceLanguageCode = languageArrayList!![position].languagecode
            targetLangeCode = languageArrayList!![position].languageTitle
            sourceLangugeChooseBtn.text = sourceLanguageTitle

            Log.e(TAG, "sourceLanguagrCode: sourcewLanguageCode: $sourceLanguageCode")
            Log.e(TAG, "sourceLangeCode: sourceLanguageTitle:$sourceLanguageTitle" )


            false
        }


    }
    private fun targetLanguageChose(targetLanguageChooseBtn: Button){
        val popupMenu =  PopupMenu(context,targetLanguageChooseBtn)

        for(i in languageArrayList!!.indices){
            popupMenu.menu.add(Menu.NONE,i,i,languageArrayList!![i].languageTitle)

        }
        popupMenu.show()
        popupMenu.setOnMenuItemClickListener { menuItem ->

            val position = menuItem.itemId

            targetLangeCode = languageArrayList!![position].languagecode
            targetLanguageTitle = languageArrayList!![position].languageTitle
            targetLanguageChooseBtn.text =  targetLanguageTitle
            Log.e(TAG, "targetLanguagrCode: targetewLanguageCode: $targetLangeCode")
            Log.e(TAG, "targetLangeCode: targetLanguageTitle:$targetLanguageTitle" )


            false
        }
    }



    private fun showPopup(messageView: View) {
        // Inflate your popup layout
        val popupView = View.inflate(context, R.layout.chat_popup, null)


        // Create the PopupWindow
        val popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true// Allows it to be dismissed when touched outside
        )
        val fadeIn = android.view.animation.AnimationUtils.loadAnimation(context, R.anim.fade_in)
        val fadeOut = android.view.animation.AnimationUtils.loadAnimation(context, R.anim.fade_out)

        // Apply the animations
        popupWindow.animationStyle = R.style.PopupAnimation

        // Calculate the exact position of the message
        val location = IntArray(2)
        messageView.getLocationOnScreen(location)

        // Measure the height and width of the popup
        popupView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val popupWidth = popupView.measuredWidth
        val popupHeight = popupView.measuredHeight

        // Calculate available space above and below the message
        val spaceAbove = location[1]
        val spaceBelow = messageView.rootView.height - (location[1] + messageView.height)

        val x = location[0] + messageView.width/2 - popupWidth/2 // To center align with the message

        // Decide the y-position based on available space
        val y = if (spaceBelow >= popupHeight) {
            location[1] + messageView.height
        } else {
            location[1] - popupHeight
        }



        // Display the popup
        popupWindow.showAtLocation(messageView, Gravity.NO_GRAVITY, x, y)
        popupView.startAnimation(fadeIn)

        val slideUp = android.view.animation.AnimationUtils.loadAnimation(context, R.anim.slide_up)
        popupView.startAnimation(slideUp)

        // Optionally, you can set a dismiss listener if needed
        // popupWindow.setOnDismissListener { ... }
    }


    class SendViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val timestampTextView : TextView = itemView.findViewById(R.id.timestampTextView)

        val sendMessage = itemView.findViewById<TextView>(R.id.text_sent_message)


    }
    class ReceiveViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val timestampTextView: TextView = itemView.findViewById(R.id.timestampTextView)
        val receiveMessage = itemView.findViewById<TextView>(R.id.text_receive_message)

    }


}