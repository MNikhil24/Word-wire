package com.example.wordwire

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var textClick: TextView
    private lateinit var auth: FirebaseAuth
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize FirebaseAuth instance
        auth = FirebaseAuth.getInstance()

        // Check if the user is already logged in, navigate directly to ChatBoxActivity if true
        if (auth.currentUser != null) {
            startActivity(Intent(this, ChatBoxActivity::class.java))
            finish()
        }

        // Initialize UI elements
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        textClick = findViewById(R.id.textClick)

        // Set click listener for the login button
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                signInUser(email, password)
            } else {
                // Fields are empty, display a message
                Toast.makeText(this, "Please fill in both email and password.", Toast.LENGTH_SHORT).show()
            }
        }

        // Navigate to Signup activity when clicked
        textClick.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }
    }


    private fun signInUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this) { task ->
            if (task.isSuccessful) {
                // Login successful, navigate to ChatBoxActivity
                startActivity(Intent(this, ChatBoxActivity::class.java))
                finish()
            } else {
                // Login failed, display an error message
                Toast.makeText(this, "Login failed. Check your email and password.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
