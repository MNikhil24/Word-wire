package com.example.wordwire;

public class UserData {
    String username = null;
    String email = "";
    String uid = null;
    String imageURL = null;

    public UserData() {
    }

    public UserData(String username, String email, String uid, String imageURL) {
        this.username = username;
        this.email = email;
        this.uid = uid;
        this.imageURL = imageURL;
    }

    public UserData(String username, String email, String uid) {
        this.username = username;
        this.email = email;
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }
}
