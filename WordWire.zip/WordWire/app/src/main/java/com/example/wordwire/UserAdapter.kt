package com.example.wordwire

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class UserAdapter(mContext: Context, mUsers: List<UserData>) :
    RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    private val mContext: Context
    private val mUsers: List<UserData>

    init {
        this.mUsers = mUsers
        this.mContext = mContext
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.user_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user: UserData = mUsers[position]
        Log.d("UserAdapter", "Binding: ${user.username}, UID: ${user.uid}")
        holder.username.text = user.username
        holder.itemView.setOnClickListener {
            Log.d("UserAdapter", "Clicked: ${user.username}, UID: ${user.uid}")
            val intent = Intent(mContext, ChatActivity::class.java)
            intent.putExtra("name", user.username)
            intent.putExtra("uid", user.uid)
            mContext.startActivity(intent)
        }
    }


    override fun getItemCount(): Int {
        return mUsers.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var username: TextView
        var profile_image: ImageView

        init {
            username = itemView.findViewById(R.id.username)
            profile_image = itemView.findViewById(R.id.profile_image)
        }
    }
}