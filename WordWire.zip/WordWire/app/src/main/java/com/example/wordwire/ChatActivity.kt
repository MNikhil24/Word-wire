package com.example.wordwire

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.widget.Toolbar
import com.example.wordwire.fragments.UsersFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class ChatActivity : AppCompatActivity() {

    private lateinit var chatRecyclerview: RecyclerView
    private lateinit var messageBox: EditText
    private lateinit var sendButton: ImageView
    private lateinit var messageAdapter: MessageAdapter
    private lateinit var messageList: ArrayList<Message>
    private lateinit var ODbRef: DatabaseReference
    //private lateinit var toolbar2: Toolbar

    private var sendRoom: String? = null
    private var receiveRoom: String? = null




//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        when (item.itemId) {
//            android.R.id.home -> {
//                // Handle the "Up" button click here
//                finish() // This will close the ChatActivity and return to the previous activity (UsersFragment)
//                return true
//            }
//            R.id.action_video -> {
//                // Handle video icon click here
//                // You can open a video chat activity or perform any desired action
//                startVideoChat()
//                return true
//            }
//            R.id.action_audio -> {
//                // Handle audio icon click here
//                // You can open an audio chat activity or perform any desired action
//                startAudioChat()
//                return true
//            }
//
//            else -> return super.onOptionsItemSelected(item)
//        }
//    }

//    private fun startAudioChat() {
//        TODO("Not yet implemented")
//    }
//
//    private fun startVideoChat() {
//        TODO("Not yet implemented")
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.chat)
        val name = intent.getStringExtra("name")
        val receiveuid = intent.getStringExtra("uid")
        val senduid = FirebaseAuth.getInstance().currentUser?.uid
        ODbRef = FirebaseDatabase.getInstance().reference
        //val toolbar = findViewById<Toolbar>(R.id.toolbar1)

        sendRoom = receiveuid + senduid

        receiveRoom = senduid + receiveuid
//        val toolbar2 = findViewById<Toolbar>(R.id.toolbar1)
//        setSupportActionBar(toolbar2)
//
//        toolbar2.navigationIcon


        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = name
        supportActionBar?.setIcon(R.drawable.ic_call)
        
        //supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_video)
        // Set a click listener for the video icon (if needed)
//        toolbar2.setNavigationOnClickListener {
//            // Handle video icon click here
//            // You can open a video chat activity or perform any desired action
//        }

        chatRecyclerview = findViewById(R.id.chatRecycleview)
        messageBox = findViewById(R.id.messageBox)
        sendButton = findViewById(R.id.sendButton)
        messageList = ArrayList()
        messageAdapter = MessageAdapter(this, messageList)

        chatRecyclerview.layoutManager = LinearLayoutManager(this)
        chatRecyclerview.adapter = messageAdapter


        //logic for adding data to recycleview
        ODbRef.child("chats").child(sendRoom!!).child("messages")
            .addValueEventListener(object : ValueEventListener {
                @SuppressLint("NotifyDataSetChanged")
                override fun onDataChange(snapshot: DataSnapshot) {
                    messageList.clear()
                    for (postSnapshot in snapshot.children) {
                        val message = postSnapshot.getValue(Message::class.java)
                        messageList.add(message!!)
                    }
                    messageAdapter.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("FirebaseDatabaseError", "Error: ${error.message}")
                }

            })


        sendButton.setOnClickListener {
            val message = messageBox.text.toString().trim() // Trim any leading/trailing whitespace
            if (message.isNotEmpty()) {
                val messageObj = Message(message, senduid)

                // Save the message in the sender's chat room
                ODbRef.child("chats").child(sendRoom!!).child("messages").push()
                    .setValue(messageObj).addOnSuccessListener {
                        // Optional: You can add code here to handle the success event if needed.
                    }

                // Save the message in the recipient's chat room
                ODbRef.child("chats").child(receiveRoom!!).child("messages").push()
                    .setValue(messageObj).addOnSuccessListener {

                    }

                messageBox.setText("")
            } else {

                Toast.makeText(this, "Message cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }


    }
}