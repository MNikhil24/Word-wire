package com.example.wordwire;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.wordwire.fragments.HomeFragment;
import com.example.wordwire.fragments.UsersFragment;
import com.example.wordwire.fragments.UserProfileFragment;

public class TheViewPageAdapter extends FragmentStateAdapter {
    public TheViewPageAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }


    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new HomeFragment();
            case 1:
                return new UsersFragment();
            case 2:
                return new UserProfileFragment();
            default:
                return new UsersFragment();

        }
    }


    @Override
    public int getItemCount() {
        return 3;
    }
}
