package com.example.wordwire.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.example.wordwire.R
import com.example.wordwire.LoginActivity
import com.google.firebase.auth.FirebaseAuth

import android.util.Log
import com.example.wordwire.UserData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class UserProfileFragment : Fragment() {

    private lateinit var profileImageView: ImageView
    private lateinit var usernameTextView: TextView
    private lateinit var usernameEditText: EditText
    private lateinit var changeProfilePicButton: Button
    private lateinit var changeUsernameButton: Button
    private lateinit var logoutButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_user_profile, container, false)

        // Initialize UI elements
        profileImageView = rootView.findViewById(R.id.profileImageView)
        usernameTextView = rootView.findViewById(R.id.usernameTextView)
        usernameEditText = rootView.findViewById(R.id.usernameEditText)
        changeProfilePicButton = rootView.findViewById(R.id.changeProfilePicButton)
        changeUsernameButton = rootView.findViewById(R.id.changeUsernameButton)
        logoutButton = rootView.findViewById(R.id.logoutButton)

        // Set click listeners for buttons
        changeProfilePicButton.setOnClickListener {

        }

        changeUsernameButton.setOnClickListener {
            val newUsername = usernameEditText.text.toString()
            val currentUserEmail = FirebaseAuth.getInstance().currentUser?.email

            if (currentUserEmail != null) {
                val usersRef = FirebaseDatabase.getInstance().getReference("users")

                usersRef.orderByChild("email").equalTo(currentUserEmail)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                            if (dataSnapshot.exists()) {
                                for (userSnapshot in dataSnapshot.children) {
                                    userSnapshot.ref.child("username").setValue(newUsername)
                                }
                            } else {
                                Log.e("UserProfileFragment", "User not found.")
                            }
                        }

                        override fun onCancelled(databaseError: DatabaseError) {
                            Log.e("UserProfileFragment", "Error updating username", databaseError.toException())
                        }
                    })
            }
            usernameTextView.text = newUsername
        }


        logoutButton.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(activity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            activity?.finish()
        }


        return rootView
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadUserProfile()
    }

    private fun loadUserProfile() {
        val currentUserEmail = FirebaseAuth.getInstance().currentUser?.email
        if (currentUserEmail != null) {
            val usersRef = FirebaseDatabase.getInstance().getReference("users")
            usersRef.orderByChild("email").equalTo(currentUserEmail)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for (userSnapshot in dataSnapshot.children) {
                                val userData = userSnapshot.getValue(UserData::class.java)
                                usernameTextView.text = userData?.username
                            }
                        } else {
                            Log.e("UserProfileFragment", "User not found.")
                        }
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                        // Handle database error
                        Log.e("UserProfileFragment", "Error fetching user data", databaseError.toException())
                    }
                })
        }
    }


}
