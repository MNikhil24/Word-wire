package com.example.wordwire

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.database.FirebaseDatabase

class SignupActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        auth = FirebaseAuth.getInstance()
        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val confirmPasswordEditText = findViewById<EditText>(R.id.confirmPasswordEditText)
        val usernameEditText = findViewById<EditText>(R.id.usernameEditText)
        val signupButton = findViewById<Button>(R.id.button3)
        val textClick = findViewById<TextView>(R.id.textClick)

        signupButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()
            val username = usernameEditText.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty()) {
                if (password == confirmPassword) {
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this) { task ->
                            if (task.isSuccessful) {
                                // Signup successful, save user data to the database
                                val user = auth.currentUser
                                val uid: String? = user?.uid


                                val userData = UserData(username, email, uid)
                                val userRef = FirebaseDatabase.getInstance().reference.child("users").child(uid ?: "user_id")

                                userRef.setValue(userData)

                                // Navigate to the login activity
                                val intent = Intent(this, LoginActivity::class.java)
                                startActivity(intent)
                                finish()
                            } else {
                                // Signup failed, display an error message
                                val errorMessage = when (task.exception) {
                                    is FirebaseAuthWeakPasswordException ->
                                        "Password is too weak."

                                    is FirebaseAuthInvalidCredentialsException ->
                                        "Invalid email format."

                                    is FirebaseAuthUserCollisionException ->
                                        "Email is already registered."

                                    else -> "Signup failed."
                                }
                                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
                            }
                        }
                } else {
                    // Passwords do not match, showing an error message
                    val passwordMismatchError = "Passwords do not match."
                    Toast.makeText(this, passwordMismatchError, Toast.LENGTH_SHORT).show()
                }
            }
        }

        textClick.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}
